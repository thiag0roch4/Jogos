'use strict';
/*
The Pick Game

This game app is to reinforce your knowledge and skills with DOM and Events.

Demo:  https://pig-game-v2.netlify.app/

This is a two player game.

The current Player rolls the dice, an image of a random die face is shown,
    and the value on the die is added to the player's current score
which is shown by the number in the 'CURRENT' box.

The player may roll as many times as they choose.

Whenever the player rolls a one, the player's current score is reset to 
zero and the game play passes to the other player.

This is the motivation for a player selecting "HOLD".  
When the player selects "HOLD", the current score is added to the total score
which is shown as a large number under 'PLAYER 1' or 'PLAYER 2.
The current score is reset to zero.And the game passes to the other player.

The first player to reach 100 points then wins the game.

There is also a way of resetting the game.If the 'NEW GAME' button is pressed,
    the dice will disappear and all the scores are set back to zero.


Included in this starter is a flowchart which is a not-too-detailed
visualization of the structure of the application.
On left side of the flowchart, the yellow represents the possible 
actions that the user can take.
Flowing from each action is the representation of what happens in the application.

*/

//Classes of text displayed
const mainClassPlayer1 = document.querySelector(`.player--0`);
const scorePlayer1 = document.querySelector(`.player--0 .score`);
let currentPlayer1 = document.querySelector(`.player--0 .current-score`);
const mainClassPLayer2 = document.querySelector(`.player--1`);
const scorePlayer2 = document.querySelector(`.player--1 .score`);
const currentPlayer2 = document.querySelector(`.player--1 .current-score`);
const activePlayers = document.querySelector(`.player`);
//buttons
const newGame = document.querySelector(`.btn--new`);
const rollDice = document.querySelector(`.btn--roll`);
const holdBtn = document.querySelector(`.btn--hold`);

//color set up
const color = document.querySelector(`.player--0`);
const color1 = document.querySelector(`.player--1`);

//scores set to 0
scorePlayer1.textContent = 0;
scorePlayer2.textContent = 0;

//Game-winner
const gameWinner = document.querySelector(`player--winner`);
const nameWinner = document.querySelector(`.name`);

//dice set up
const image = document.querySelector(`.dice`);
image.classList.add('hidden');
let randNumber;
let currentScore = 0;
//    player1 is false
//    player2is true
let playerTurn = false;

//  DICE ROLL

rollDice.addEventListener(`click`, function () {
  randNumber = Math.trunc(Math.random() * 6 + 1);
  image.classList.remove(`hidden`);
  image.src = `dice-${randNumber}.png`;
  if (randNumber === 1) {
    if (playerTurn === false) {
      playerTurn = true;
    } else {
      playerTurn = false;
    }
    currentScore = 0;
    currentPlayer1.textContent = currentScore;
    currentPlayer2.textContent = currentScore;
    color1.classList.toggle(`player--active`);
    color.classList.toggle(`player--active`);
  } else {
    if (playerTurn === false) {
      if (randNumber > 1) {
        currentScore += randNumber;
        currentPlayer1.textContent = currentScore;
      }
    } else {
      if (randNumber > 1) {
        currentScore += randNumber;
        currentPlayer2.textContent = currentScore;
      }
    }
  }
});

//  score variables
let player1Score = 0;
let player2Score = 0;
holdBtn.addEventListener(`click`, function () {
  if (playerTurn === false) {
    console.log(currentScore);
    player1Score += currentScore;
    scorePlayer1.textContent = player1Score;
    currentPlayer1.textContent = 0;
    currentScore = 0;
    playerTurn = true;
  } else {
    player2Score += currentScore;
    scorePlayer2.textContent = player2Score;
    currentPlayer2.textContent = 0;
    currentScore = 0;
    playerTurn = false;
  }

  //  GAME WINNER
  const playerActive = document.querySelector(`.player--active`);
  if (player1Score >= 100) {
    randNumber = 0;
    currentScore = 0;
    image.classList.remove(`hidden`);
    mainClassPlayer1.classList.add(`player--winner`, `name`);
    playerActive.classList.remove(`active`); //*******************************
  } else if (player2Score >= 100) {
    randNumber = 0;
    activePlayers.classList.remove(`hidden`);
    mainClassPLayer2.classList.add(`player--winner`, `name`);
  }

  color1.classList.toggle(`player--active`);
  color.classList.toggle(`player--active`);
});

newGame.addEventListener(`click`, function () {
  player1Score = 0;
  player2Score = 0;
  scorePlayer1.textContent = 0;
  scorePlayer2.textContent = 0;
  currentScore = 0;
  image.classList.add(`hidden`);
  mainClassPlayer1.classList.remove(`player--winner`, `name`);
  mainClassPLayer2.classList.remove(`player--winner`, `name`);
});
